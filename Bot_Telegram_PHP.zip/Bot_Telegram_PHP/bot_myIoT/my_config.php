<?php
	define('IP','x.x.x.x');
	define('DBUSER','usuarioDeLaBBDD');
	define('DBPWD','claveDelUsuarioAnterior');
	define('DBHOST','localhost');
	define('DBNAME','nombreDeLaBBDD');
	define('BOT_TOKEN','TokenDelBotTelegram');
	
	define('TENANT_NAME','nombreDelUsuarioTenantMyIoT');
	define('TENANT_PWD','claveDelUsuarioTenant');
	define('TENANT_ID',"IDdelTenant");	
	define('PATRON_ID',"IDdelCustomerPatron");	
	

