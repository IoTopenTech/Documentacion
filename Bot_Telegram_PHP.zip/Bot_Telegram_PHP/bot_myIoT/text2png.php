<?php
header("Content-type: image/png");

$string = $_GET['cadena'];
if(isset($_GET['contenido'])){
	//Separamos por líneas
	$contenido = explode('<br/>',urldecode($_GET['contenido']));
	//Separamos por estilo </b>
	foreach ($contenido as $clave=>$valor){
		$contenido[$clave]=explode('</b>',$contenido[$clave]);
	}
}else{
	$contenido=array();
}
$font=4;
$fontttf  = __DIR__."/vendor/bozhinov/pchart/pChart/fonts/Forgotte.ttf";
$fontttf2  = __DIR__."/vendor/bozhinov/pchart/pChart/fonts/MankSans.ttf";

//Tengo que calcular el tamaño de la imagen = logo (750x200) + path (750x50) + contenido (?)
//$width  = imagefontwidth($font) * strlen($string);
//$height = imagefontheight($font);
$width=750;
$height=270+count($contenido)*35;

$image = imagecreatetruecolor ($width,$height);

$white = imagecolorallocate ($image,255,255,255);
$black = imagecolorallocate ($image,0,0,0);
$grey = imagecolorallocate ($image,80,80,80);

imagefill($image,0,0,$white);
$logo=imagecreatefromgif(realpath(__DIR__.'/logo_my_iot_open_tech.gif'));
imagecopy($image,$logo,0,0,0,0,750,200);



//imagestring ($image,$font,0,0,realpath(__DIR__.'/logo_my_iot_open_tech.png'),$black);
imagettftext($image, 24, 0, 20, 225, $black, realpath($fontttf), $string);
for($i=0;$i<count($contenido);$i++){
	$abscisa=20;	
	foreach($contenido[$i] as $valor){
		if(substr($valor,0,3)=='<b>'){
			$box=imagettftext($image, 24, 0, $abscisa, 270+(35*$i), $grey, realpath($fontttf2), substr($valor,3));			
		}else{
			$box=imagettftext($image, 24, 0, $abscisa, 270+(35*$i), $black, realpath($fontttf2), $valor);
		}
		$abscisa=$box[2]+10;
	}
}

imagepng ($image);
imagedestroy($image);
imagedestroy($logo);
?>
