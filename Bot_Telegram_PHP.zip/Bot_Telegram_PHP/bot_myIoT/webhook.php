<?php

require_once __DIR__."/vendor/autoload.php";

use TuriBot\Client;

include('my_config.php');

$mysqli = new mysqli(DBHOST, DBUSER, DBPWD, DBNAME);
if ($mysqli->connect_errno) {
	die("Falló la conexión con la base de datos");
}
$mysqli->set_charset("utf8");

if (!isset($_GET["api"])) {
    exit();
}

$client = new Client($_GET["api"], false);

//Petición desde myIoT
if (isset($_GET["codigo"]) && isset($_GET["customerID"]) && $_GET["codigo"]=="") {
	//Si el código está vacío, el usuario quiere desvincularse
	if($_GET["codigo"]==""){
		$stmt = $mysqli->prepare("DELETE FROM users WHERE customer_id=?");		
		$stmt->bind_param("s", $_GET["customerID"]);
		$stmt->execute();
		exit();
	}
}
	
if (isset($_GET["codigo"]) && isset($_GET["customerID"])) {
	//Si existe el código en la tabla codigos
	//y no ha cadudaco (2 minutos)
	//trasladamos a la tabla users
	//Empiezo separando el id del código
	$id=explode('.',$_GET["codigo"])[0];
	$codigo=explode('.',$_GET["codigo"])[1];
	
	if ($stmt = $mysqli->prepare("SELECT chat_id,fecha FROM codigos WHERE id=? AND codigo=?")) {
		$stmt->bind_param("is", $id,$codigo);
		$stmt->execute();
		$stmt->bind_result($chat_id,$fecha);
		
		if($stmt->fetch()){
			//Hay una coincidencia
			//Han pasado menos de 2 minutos
			
			$timestamp = strtotime($fecha);
			if(time() - $timestamp <120){
				$stmt->close();
				if ($stmt = $mysqli->prepare("INSERT INTO users (chat_id,customer_id) VALUES (?,?) ON DUPLICATE KEY UPDATE chat_id=VALUES(chat_id),customer_id=VALUES(customer_id)")){
					$stmt->bind_param("is", $chat_id,$_GET["customerID"]);
					$stmt->execute();
					$client->sendMessage($chat_id, 'Este chat de Telegram se ha vinculado correctamente a su cuenta de myIoT. A continuación se muestran las entidades de su activo ROOT');
					
					$resultado=mostrar_root($_GET["customerID"]);
					if($resultado){
						$menu["inline_keyboard"] = $resultado;
						//$client->sendMessage($chat_id, var_export($menu["inline_keyboard"],true));
						
						$client->sendPhoto($chat_id,'https://www.bot.my.iotopentech.io/'.BOT_TOKEN.'/text2png.php?cadena=ROOT&random='.time(),null,null,null,null,null,null,$menu);
					}
				}
			}else{
				exit();
			}
		}
	}		
    exit();
}

//Petición desde Telegram
//Aquí el update se obtiene del propio telegram
$update = $client->getUpdate();
if (!isset($update)) {
    exit('json error');
}

function vinculado($chat_id){
	$mysqli = new mysqli(DBHOST, DBUSER, DBPWD, DBNAME);
	if ($mysqli->connect_errno) {
		die("Falló la conexión con la base de datos");
	}
	$mysqli->set_charset("utf8");
	$query = "SELECT * FROM users WHERE chat_id=$chat_id LIMIT 1";
	$resultado = $mysqli->query($query);
	$fila = $resultado->fetch_row();
	if($fila){
		return true;
	}else{
		return false;
	}
}

if (isset($update->message) or isset($update->edited_message)) {
    $chat_id = $client->easy->chat_id;
    $message_id = $client->easy->message_id;
    $text = $client->easy->text;
	if ($text === "/link") {
		//Genero un código de 32 caracteres
		$codigo="";
		$pool="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		while (strlen($codigo)<32){
			$codigo.=substr($pool,rand(0,strlen($pool)-1),1);
		}
		$query = "INSERT INTO codigos VALUES (NULL, '$chat_id','$codigo','" . date("Y-m-d H:i:s") . "')";

            $mysqli->query($query);
            $mysqli->error;
            $codigo = $mysqli->insert_id.".".$codigo;
		$client->sendMessage($chat_id, "Para configurar la integración entre Telegram y myIoT, introduzca el siguiente código en su dashboard de myIoT antes de 2 minutos: <b>Configuración>Perfil de usuario>Integración con el bot myIoT_bot</b>",'HTML');
		$client->sendMessage($chat_id,$codigo);
	}
	if ($text === "/start") {
		$client->sendMessage($chat_id, 'Bienvenido al bot de integración con myIoT');
		
		$customer_id=get_customer_id($chat_id);
		if($customer_id===false){
			$client->sendMessage($chat_id, 'Use el comando /link para vincular este bot con su cuenta de myIoT');
			exit();
		}
		$resultado=mostrar_root($customer_id);
		if($resultado){
			$menu["inline_keyboard"] = $resultado;

			$client->sendPhoto($chat_id,'https://www.bot.my.iotopentech.io/'.BOT_TOKEN.'/text2png.php?cadena=ROOT&random='.time(),null,null,null,null,null,null,$menu);
			
		}else{
			$client->sendMessage($chat_id, 'Use el comando /link para vincular este bot con su cuenta de myIoT');
		}
    }
	/*
	//Tengo que comprobar que sigue vinculado
	if(!vinculado($chat_id)){
		$client->sendMessage($chat_id,"Este chat no está vinculado a ninguna cuenta de myIoT.\nUse el comando /link para vincular este bot con su cuenta de myIoT");
		exit('Desvinculado');
	}
	*/
    
}

if (isset($update->callback_query)) {
    $id = $update->callback_query->id;
    $message_chat_id = $update->callback_query->message->chat->id;
	$message_message_id = $update->callback_query->message->message_id;
	if(!vinculado($message_chat_id)){
		$client->editMessageText($message_chat_id, $message_message_id, null, "Este chat no está vinculado a ninguna cuenta de myIoT.\nUse el comando /link para vincular este bot con su cuenta de myIoT", null, null, null, null);
		exit('Desvinculado');
	}
	$respuesta=json_decode($update->callback_query->data);
	if(isset($respuesta->nav)){		
		$resultado=mostrar_ubicacion($respuesta->own,$respuesta->nav);
		if($resultado){
			$menu["inline_keyboard"] = $resultado;
			$path=obtener_path($respuesta->own,"ASSET");
			if($path[0]!="ROOT"){
				array_unshift($menu["inline_keyboard"][count($menu["inline_keyboard"])-1],["text"=> "⬆️","callback_data" => "{\"nav\":".(isset($respuesta->to)?$respuesta->to:0).",\"own\":\"".$path[1][count($path[1])-2]."\"}"]);
			}
			
			$client->answerCallbackQuery($id, "Cargando");
			$imagen=array("type"=>"photo","media"=>"https://www.bot.my.iotopentech.io/".BOT_TOKEN."/text2png.php?cadena=".$path[0]."&random=".time());
			
			$client->editMessageMedia($message_chat_id, $message_message_id, null, $imagen, $menu);
			
		}else{
			$client->editMessageText($message_chat_id, $message_message_id, null, "Se ha producido un error de navegación", null, null, null, null);
			$client->answerCallbackQuery($id, "Error");
		}
	}else if(isset($respuesta->dev)){
		$resultado=mostrar_dispositivo($respuesta->dev);
		
		$path=obtener_path($respuesta->dev,"DEVICE");
		$menu=[];
		$menu["inline_keyboard"]=[[["text"=> "⬆️","callback_data" => "{\"nav\":".(isset($respuesta->to)?$respuesta->to:0).",\"own\":\"".$path[1][count($path[1])-2]."\"}"],["text"=> "🔄️","callback_data" => "{\"dev\":\"".$respuesta->dev."\"}"]]];
		
		$client->answerCallbackQuery($id, "Cargando");
		$imagen=array("type"=>"photo","media"=>"https://www.bot.my.iotopentech.io/".BOT_TOKEN."/text2png.php?cadena=".$path[0]."&contenido=".urlencode($resultado)."&random=".time());

		$client->editMessageMedia($message_chat_id, $message_message_id, null, $imagen, $menu);
	}
}


function get_customer_id($chat_id){
	$mysqli = new mysqli(DBHOST, DBUSER, DBPWD, DBNAME);
	if ($mysqli->connect_errno) {
		die("Falló la conexión con la base de datos");
	}
	$mysqli->set_charset("utf8");
	$query = "SELECT customer_id FROM users where chat_id=$chat_id LIMIT 1";
	$resultado = $mysqli->query($query);
	$fila = $resultado->fetch_row();
	$mysqli->close();
	if(!is_null($fila)){
		return $fila[0];
	}else{
		return false;
	}
}
function obtener_token(){
	$mysqli = new mysqli(DBHOST, DBUSER, DBPWD, DBNAME);
	if ($mysqli->connect_errno) {
		die("Falló la conexión con la base de datos");
	}
	$mysqli->set_charset("utf8");
	$query = "SELECT token FROM my_token LIMIT 1";
	$resultado = $mysqli->query($query);
	$fila = $resultado->fetch_row();
	$JWT = $fila[0];

	//echo $JWT;

	$curl = curl_init();
	$headers = [
		"X-Authorization: Bearer $JWT",
		"Accept: application/json"
	];

	curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($curl, CURLOPT_URL, 'http://'.IP.':8080/api/tenant/'. TENANT_ID);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);

	$curl_response = curl_exec($curl);
	
	if ($curl_response === false) {
		//$info = curl_getinfo($curl);
		curl_close($curl);
		die('SE HA PRODUCIDO UN ERROR DE TIPO 0');
	}
		
	curl_close($curl);
	$decoded = json_decode($curl_response);
	//var_dump($decoded); 
	if (isset($decoded->status) && $decoded->status == 401) {		
		//El token ha expirado
		$url = 'http://'.IP.':8080/api/auth/login';
		$options = array(
			'http' => array(
				'header' => "Content-type: application/jsonrn",
				'method' => 'POST',
				'content' => '{"username":"' . TENANT_NAME . '", "password":"' . TENANT_PWD . '"}'
			),
		);
		$context = stream_context_create($options);
		$result = file_get_contents($url, false, $context);
		$obj = json_decode($result);
		if (!isset($obj->token)) {
			die('SE HA PRODUCIDO UN ERROR DE TIPO 1');
		}

		$query = "UPDATE my_token SET token='" . $obj->token . "' WHERE 1";
		$mysqli->query($query);
		$JWT = $obj->token;		
		
		//var_dump($JWT);
	} else if (isset($decoded->id) && $decoded->id->entityType == "TENANT") {
		//Todo bien; no hago nada El token sigue vigente
	} else {
		die('SE HA PRODUCIDO UN ERROR DE TIPO 2');
	}
	$mysqli->close();
	return $JWT;
}

function mostrar_root($customerID){	
	$JWT=obtener_token();
	//Obtener el activo root
	//Y sus relaciones FROM de tipo Contains
	$curl = curl_init();
	$headers = [
		"X-Authorization: Bearer $JWT",
		"Accept: application/json"
	];

	curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($curl, CURLOPT_URL, 'http://'.IP.':8080/api/customer/' . $customerID.'/assets?type=ROOT&limit=1');
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);

	$curl_response = curl_exec($curl);
	if ($curl_response === false) {
		//$info = curl_getinfo($curl);
		curl_close($curl);
		die('SE HA PRODUCIDO UN ERROR DE TIPO 0');
	}
		
	curl_close($curl);
	$decoded = json_decode($curl_response);	
	if(isset($decoded) && isset($decoded->data) && isset($decoded->data[0])&& isset($decoded->data[0]->id)){
		$root_id= $decoded->data[0]->id->id;
	}else{
		return false;
	}
	return mostrar_ubicacion($root_id,0);
	
}
function mostrar_ubicacion($padre,$inicio){
	//$padre es el id del activo que estamos mostrando
	//Se deben mostrar los 5 siguientes desde $inicio (incluido)
	
	//Obteno el token
	//Luego las relaciones
	//Las ordeno por activo/dispositivo,nombre
	//Contesto con la estructura de botones
	$JWT=obtener_token();
	$curl = curl_init();
	$headers = [
		"X-Authorization: Bearer $JWT",
		"Accept: application/json"
	];

	curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($curl, CURLOPT_URL, 'http://'.IP.':8080/api/relations/info?fromId='.$padre.'&fromType=ASSET');
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);

	$curl_response = curl_exec($curl);
	if ($curl_response === false) {
		//$info = curl_getinfo($curl);
		curl_close($curl);
		die('SE HA PRODUCIDO UN ERROR DE TIPO 0');
	}
		
	curl_close($curl);
	$decoded = json_decode($curl_response);
	usort($decoded, "entidad_nombre");
	$total=count($decoded);
	$menu=[];
	if($inicio==='null'){
		$inicio=$total-5;
	}
	$minimo=max($inicio,0);
	if($minimo>$total-5){
		$minimo=$total-5;
	}
	$maximo=min($minimo+4,$total-1);
	
	$i=0;
	foreach($decoded as $valor){
		if($i>$maximo){
			break;
		}
		if($i>=$minimo){
			if($valor->to->entityType=="ASSET"){
			//es un activo
			array_push($menu,[["text"=> "📁 ".substr($valor->toName,strpos($valor->toName,'_')+1),"callback_data" => "{\"nav\":0,\"own\":\"".$valor->to->id."\",\"to\":$minimo}"]]);
			}else{
				//Es un dispositivo
				array_push($menu,[["text"=> substr($valor->toName,strpos($valor->toName,'_')+1),"callback_data" => "{\"dev\":\"".$valor->to->id."\",\"to\":$minimo}"]]);
			}
			
		}
		$i++;
	}
	//Inlcluir la barra de navegación
	$barra_navegacion=[];
	
	array_push($barra_navegacion,["text"=> "⏮","callback_data" => "{\"nav\":0,\"own\":\"$padre\"}"]);
	array_push($barra_navegacion,["text"=> "⏪","callback_data" => "{\"nav\":".($minimo-5).",\"own\":\"$padre\"}"]);
	array_push($barra_navegacion,["text"=> "⏩","callback_data" => "{\"nav\":".($minimo+5).",\"own\":\"$padre\"}"]);
	array_push($barra_navegacion,["text"=> "⏭","callback_data" => "{\"nav\":\"null\",\"own\":\"$padre\"}"]);
	array_push($menu,$barra_navegacion);
	return $menu;
}
function entidad_nombre($a,$b){
	if($a->to->entityType=="ASSET" && $b->to->entityType=="DEVICE"){
		return -1;
	}
	if($a->to->entityType=="DEVICE" && $b->to->entityType=="ASSET"){
		return 1;
	}
	//Legados aquí, son los dos ASSETS o los dos DEVICES
	$nombre_a=substr($a->toName,strpos($a->toName,'_')+1);
	$nombre_b=substr($b->toName,strpos($b->toName,'_')+1);
	if ($nombre_a<$nombre_b){
		return -1;
	}
	if ($nombre_a>$nombre_b){
		return 1;
	}
	//Llegados aquí, son del mismo tipo y con el mismo nombre
	if($a->to->id<$b->to->id){
		return -1;
	}else{
		return 1;
	}
}
function obtener_path($id,$type){	
	//Primero tengo que obtener el nombre del actual, y si es ROOT he terminado
	$JWT=obtener_token();
	$curl = curl_init();
	$headers = [
		"X-Authorization: Bearer $JWT",
		"Accept: application/json"
	];

	curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($curl, CURLOPT_URL, 'http://'.IP.':8080/api/'.($type=="ASSET"?'asset':'device').'/'.$id);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);

	$curl_response = curl_exec($curl);
	if ($curl_response === false) {
		//$info = curl_getinfo($curl);
		curl_close($curl);
		die('SE HA PRODUCIDO UN ERROR DE TIPO 0');
	}
		
	curl_close($curl);
	$decoded = json_decode($curl_response);
	//Tengo que recorrer el árbol de relaciones Contains en sentido To hasta llegar al root
	$path=substr($decoded->name,strpos($decoded->name,'_')+1);
	$path_id=[$id];
	if($path=="ROOT"){
		return [$path,[$path_id]];
	}
	do{
		$JWT=obtener_token();
		$curl = curl_init();
		$headers = [
			"X-Authorization: Bearer $JWT",
			"Accept: application/json",
			"Content-type: application/json"
		];
		$query='{ 
   "filters": [ 
     {
       "relationType": "Contains", 
       "entityTypes": [
         "ASSET" 
       ] 
     } 
   ], 
   "parameters": {     
     "rootId":"'.$id.'",
     "rootType": "'.$type.'", 
     "direction": "TO", 
     "relationTypeGroup": "COMMON", 
     "maxLevel": 1, 
     "fetchLastLevelOnly": false
   } 
 }';
		curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($curl, CURLOPT_URL, 'http://'.IP.':8080/api/relations/info');
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS,$query);

		$curl_response = curl_exec($curl);
		if ($curl_response === false) {
			//$info = curl_getinfo($curl);
			curl_close($curl);
			die('SE HA PRODUCIDO UN ERROR DE TIPO 0');
		}
		curl_close($curl);
		
		$decoded = json_decode($curl_response);
		//Sólo debería haber una
		$path=substr($decoded[0]->fromName,strpos($decoded[0]->fromName,'_')+1)." / ".$path;
		$id=$decoded[0]->from->id;
		array_unshift($path_id,$id);
		//actualizo el type
		$type=$decoded[0]->from->entityType;
	}while(substr($decoded[0]->fromName,strpos($decoded[0]->fromName,'_')+1)!="ROOT");
	return [$path,$path_id];
}
function mostrar_dispositivo($id){
	//Obtengo el atributo tooltip
	//Primero tengo que obtener el nombre del actual, y si es ROOT he terminado
	$JWT=obtener_token();
	$curl = curl_init();
	$headers = [
		"X-Authorization: Bearer $JWT",
		"Accept: application/json"
	];

	curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($curl, CURLOPT_URL, 'http://'.IP.':8080/api/plugins/telemetry/DEVICE/'.$id.'/values/attributes?keys=tooltip,ultimaAlarma');

	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);

	$curl_response = curl_exec($curl);
	if ($curl_response === false) {
		//$info = curl_getinfo($curl);
		curl_close($curl);
		die('SE HA PRODUCIDO UN ERROR DE TIPO 0');
	}
		
	curl_close($curl);
	$decoded = json_decode($curl_response);
	$tooltip="";
	$ultimaAlarma="";
	if(isset($decoded[0]) && isset($decoded[0]->value)){
		if($decoded[0]->key=='tooltip'){
			$tooltip=$decoded[0]->value;
		}else if($decoded[0]->key=='ultimaAlarma'){
			$ultimaAlarma=$decoded[0]->value;
		}
	}else{
		return "No se ha podido obtener<br/>la última telemetría.";
	}
	if(isset($decoded[1]) && isset($decoded[1]->value)){
		if($decoded[1]->key=='tooltip'){
			$tooltip=$decoded[1]->value;
		}else if($decoded[1]->key=='ultimaAlarma'){
			$ultimaAlarma=$decoded[1]->value;
		}
	}
	return $tooltip.'<br/>----<br/>'.$ultimaAlarma;
	
}
