<?php

require_once "vendor/autoload.php";

use TuriBot\Client;


if (!isset($_GET["api"])) {
	exit();
}

$client = new Client($_GET["api"], false);

$update = $client->getUpdate();
if (!isset($update)) {
	exit('json error');
}
$menu["inline_keyboard"] = [
		[
			[
				"text"          => "Chat ID",
				"callback_data" => "btn1",
			],
			[
				"text"          => "Message ID",
				"callback_data" => "btn2"
			]
		],
	];

if (isset($update->message) or isset($update->edited_message)) {
	$chat_id = $client->easy->chat_id;
	$message_id = $client->easy->message_id;
	$text = $client->easy->text;
	$nombre = $client->easy->first_name;
	$client->sendMessage($chat_id, "Hola ".$nombre, null, null, null, null, null, null, $menu);
}
if (isset($update->callback_query)) {
	$id = $update->callback_query->id;
	$message_chat_id = $update->callback_query->message->chat->id;
	$message_message_id = $update->callback_query->message->message_id;
	if ($update->callback_query->data === "btn1") {
		$client->answerCallbackQuery($id, "Botón 1");
		$client->editMessageText($message_chat_id, $message_message_id, null, "Chat ID: ".$message_chat_id, null, null, null, $menu);
	} elseif ($update->callback_query->data === "btn2") {
		$client->answerCallbackQuery($id, "Botón 2");
		$client->editMessageText($message_chat_id, $message_message_id, null, "Message ID: ".$message_message_id, null, null, null, $menu);
	}
}
